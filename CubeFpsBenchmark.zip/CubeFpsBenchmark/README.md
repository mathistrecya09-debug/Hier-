# Cube FPS Benchmark

Application Android native (Kotlin + OpenGL ES 2.0), sans dépendance externe.

## Prérequis
- Android Studio (Koala ou plus récent) — inclut le JDK 17 et le SDK Android
- Un téléphone Android 7.0+ (API 24) avec OpenGL ES 2.0

## Générer l'APK (méthode Android Studio)
1. Décompressez le projet, puis **File > Open** et choisissez le dossier `CubeFpsBenchmark`.
2. Laissez la synchronisation Gradle se terminer (Android Studio télécharge Gradle et le SDK 34 si besoin).
3. **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Cliquez sur **locate** : `app/build/outputs/apk/debug/app-debug.apk`.
5. Copiez l'APK sur le téléphone et installez-le (autorisez les « sources inconnues »), ou branchez le téléphone en mode débogage USB et cliquez sur ▶ Run.

## En ligne de commande
```
gradle wrapper --gradle-version 8.7     # une seule fois (génère ./gradlew)
./gradlew assembleDebug                 # APK debug installable
```
Si SDK absent : définir `ANDROID_HOME` ou créer `local.properties` avec `sdk.dir=/chemin/vers/Android/Sdk`.

## APK release signé
```
keytool -genkeypair -v -keystore cube.jks -alias cube -keyalg RSA -keysize 2048 -validity 10000
./gradlew assembleRelease
zipalign -v -p 4 app/build/outputs/apk/release/app-release-unsigned.apk cube-aligned.apk
apksigner sign --ks cube.jks --out cube-release.apk cube-aligned.apk
```
(`zipalign` et `apksigner` sont dans `Android/Sdk/build-tools/<version>/`.)
Ou dans Android Studio : **Build > Generate Signed Bundle / APK > APK**.

## À savoir sur la mesure
- Les FPS = nombre d'appels réels à `onDrawFrame()` divisé par le temps mesuré (`System.nanoTime()`), sur des fenêtres de 0,5 s.
- Android synchronise l'affichage (VSync) : le FPS est plafonné à la fréquence de l'écran (60, 90, 120 Hz). Un cube seul est très léger, donc il restera proche de ce plafond.
