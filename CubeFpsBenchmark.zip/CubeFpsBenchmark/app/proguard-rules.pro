# Aucune règle spécifique nécessaire.
