package com.example.cubefps

import android.opengl.GLES20
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Cube 3D rendu avec OpenGL ES 2.0.
 * Optimisations : VBO/IBO statiques (données envoyées une seule fois au GPU),
 * sommets entrelacés (position + normale + couleur), un seul draw call.
 */
class Cube {

    private val program: Int
    private val aPos: Int
    private val aNormal: Int
    private val aColor: Int
    private val uMvp: Int
    private val uModel: Int
    private val buffers = IntArray(2) // 0 = sommets, 1 = indices

    init {
        val (vertices, indices) = buildGeometry()

        program = createProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aNormal = GLES20.glGetAttribLocation(program, "aNormal")
        aColor = GLES20.glGetAttribLocation(program, "aColor")
        uMvp = GLES20.glGetUniformLocation(program, "uMvp")
        uModel = GLES20.glGetUniformLocation(program, "uModel")

        val vb = ByteBuffer.allocateDirect(vertices.size * 4).order(ByteOrder.nativeOrder())
            .asFloatBuffer().put(vertices).also { it.position(0) }
        val ib = ByteBuffer.allocateDirect(indices.size * 2).order(ByteOrder.nativeOrder())
            .asShortBuffer().put(indices).also { it.position(0) }

        GLES20.glGenBuffers(2, buffers, 0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, buffers[0])
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, vertices.size * 4, vb, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, buffers[1])
        GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, indices.size * 2, ib, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
    }

    fun draw(mvp: FloatArray, model: FloatArray) {
        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, buffers[0])
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, buffers[1])

        val stride = FLOATS_PER_VERTEX * 4
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, stride, 0)
        GLES20.glEnableVertexAttribArray(aNormal)
        GLES20.glVertexAttribPointer(aNormal, 3, GLES20.GL_FLOAT, false, stride, 3 * 4)
        GLES20.glEnableVertexAttribArray(aColor)
        GLES20.glVertexAttribPointer(aColor, 3, GLES20.GL_FLOAT, false, stride, 6 * 4)

        GLES20.glDrawElements(GLES20.GL_TRIANGLES, 36, GLES20.GL_UNSIGNED_SHORT, 0)

        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aNormal)
        GLES20.glDisableVertexAttribArray(aColor)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
    }

    companion object {
        private const val FLOATS_PER_VERTEX = 9

        // normale, axe u, axe v (u x v = normale => sens anti-horaire vu de l'extérieur)
        private val FACES = arrayOf(
            floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f),
            floatArrayOf(-1f, 0f, 0f, 0f, 0f, 1f, 0f, 1f, 0f),
            floatArrayOf(0f, 1f, 0f, 0f, 0f, 1f, 1f, 0f, 0f),
            floatArrayOf(0f, -1f, 0f, 1f, 0f, 0f, 0f, 0f, 1f),
            floatArrayOf(0f, 0f, 1f, 1f, 0f, 0f, 0f, 1f, 0f),
            floatArrayOf(0f, 0f, -1f, 0f, 1f, 0f, 1f, 0f, 0f)
        )

        private val COLORS = arrayOf(
            floatArrayOf(0.96f, 0.35f, 0.40f),
            floatArrayOf(0.98f, 0.62f, 0.25f),
            floatArrayOf(0.98f, 0.85f, 0.30f),
            floatArrayOf(0.35f, 0.80f, 0.50f),
            floatArrayOf(0.30f, 0.60f, 0.98f),
            floatArrayOf(0.62f, 0.45f, 0.96f)
        )

        private val SIGNS = arrayOf(
            floatArrayOf(-1f, -1f), floatArrayOf(1f, -1f),
            floatArrayOf(1f, 1f), floatArrayOf(-1f, 1f)
        )

        private fun buildGeometry(): Pair<FloatArray, ShortArray> {
            val h = 0.5f
            val vertices = FloatArray(6 * 4 * FLOATS_PER_VERTEX)
            val indices = ShortArray(36)
            var vi = 0
            var ii = 0
            for (f in 0 until 6) {
                val face = FACES[f]
                val base = f * 4
                for (c in 0 until 4) {
                    val su = SIGNS[c][0]
                    val sv = SIGNS[c][1]
                    for (k in 0 until 3) {
                        vertices[vi++] = (face[k] + su * face[3 + k] + sv * face[6 + k]) * h
                    }
                    for (k in 0 until 3) vertices[vi++] = face[k]
                    for (k in 0 until 3) vertices[vi++] = COLORS[f][k]
                }
                indices[ii++] = base.toShort()
                indices[ii++] = (base + 1).toShort()
                indices[ii++] = (base + 2).toShort()
                indices[ii++] = base.toShort()
                indices[ii++] = (base + 2).toShort()
                indices[ii++] = (base + 3).toShort()
            }
            return Pair(vertices, indices)
        }

        private const val VERTEX_SHADER = """
            uniform mat4 uMvp;
            uniform mat4 uModel;
            attribute vec3 aPos;
            attribute vec3 aNormal;
            attribute vec3 aColor;
            varying vec3 vColor;
            varying vec3 vNormal;
            void main() {
                vColor = aColor;
                vNormal = (uModel * vec4(aNormal, 0.0)).xyz;
                gl_Position = uMvp * vec4(aPos, 1.0);
            }
        """

        private const val FRAGMENT_SHADER = """
            precision mediump float;
            varying vec3 vColor;
            varying vec3 vNormal;
            void main() {
                vec3 light = normalize(vec3(0.4, 0.7, 0.9));
                float diff = max(dot(normalize(vNormal), light), 0.0);
                gl_FragColor = vec4(vColor * (0.35 + 0.65 * diff), 1.0);
            }
        """

        private fun compile(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) {
                val log = GLES20.glGetShaderInfoLog(s)
                GLES20.glDeleteShader(s)
                throw RuntimeException("Erreur shader : $log")
            }
            return s
        }

        private fun createProgram(vs: String, fs: String): Int {
            val p = GLES20.glCreateProgram()
            GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
            GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
            GLES20.glLinkProgram(p)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
            if (ok[0] == 0) {
                throw RuntimeException("Erreur link : " + GLES20.glGetProgramInfoLog(p))
            }
            return p
        }
    }
}
