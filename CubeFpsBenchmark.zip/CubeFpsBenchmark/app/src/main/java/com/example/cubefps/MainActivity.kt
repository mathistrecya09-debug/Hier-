package com.example.cubefps

import android.app.Activity
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var glView: GLSurfaceView
    private lateinit var renderer: CubeRenderer
    private lateinit var tvFps: TextView
    private lateinit var tvFrames: TextView
    private lateinit var tvAvg: TextView
    private lateinit var tvMinMax: TextView
    private lateinit var btnToggle: Button
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvFps = findViewById(R.id.tvFps)
        tvFrames = findViewById(R.id.tvFrames)
        tvAvg = findViewById(R.id.tvAvg)
        tvMinMax = findViewById(R.id.tvMinMax)
        btnToggle = findViewById(R.id.btnToggle)
        glView = findViewById(R.id.glView)

        renderer = CubeRenderer { stats -> runOnUiThread { showStats(stats) } }
        glView.setEGLContextClientVersion(2)
        glView.setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        glView.preserveEGLContextOnPause = true
        glView.setRenderer(renderer)
        glView.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY // image fixe tant que le test est arrêté

        btnToggle.setOnClickListener { if (running) stopTest() else startTest() }
        findViewById<Button>(R.id.btnReset).setOnClickListener { resetStats() }
    }

    private fun startTest() {
        running = true
        renderer.start()
        glView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        btnToggle.setText(R.string.stop)
        btnToggle.setBackgroundResource(R.drawable.bg_btn_stop)
    }

    private fun stopTest() {
        running = false
        renderer.stop()
        glView.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
        glView.requestRender()
        btnToggle.setText(R.string.start)
        btnToggle.setBackgroundResource(R.drawable.bg_btn_primary)
    }

    private fun resetStats() {
        renderer.resetStats()
        glView.requestRender()
        showStats(FpsStats(0f, 0, 0f, 0f, 0f))
    }

    private fun showStats(s: FpsStats) {
        val l = Locale.getDefault()
        tvFps.text = String.format(l, "%.1f", s.fps)
        tvFrames.text = String.format(l, "%,d", s.frames)
        tvAvg.text = String.format(l, "%.1f", s.avgFps)
        tvMinMax.text = String.format(l, "%.0f / %.0f", s.minFps, s.maxFps)
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
    }

    override fun onPause() {
        if (running) stopTest()
        glView.onPause()
        super.onPause()
    }
}
