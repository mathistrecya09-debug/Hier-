package com.example.cubefps

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

data class FpsStats(
    val fps: Float,
    val frames: Long,
    val avgFps: Float,
    val minFps: Float,
    val maxFps: Float
)

/**
 * Renderer OpenGL ES. Les FPS sont mesurés à partir des appels réels à onDrawFrame()
 * (une image dessinée = un appel), chronométrés avec System.nanoTime().
 * Aucune valeur n'est simulée ni fixée.
 */
class CubeRenderer(private val onStats: (FpsStats) -> Unit) : GLSurfaceView.Renderer {

    @Volatile private var running = false
    @Volatile private var timingReset = true
    @Volatile private var statsReset = false

    private var cube: Cube? = null
    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val model = FloatArray(16)
    private val vp = FloatArray(16)
    private val mvp = FloatArray(16)

    private var angleX = 20f
    private var angleY = 30f

    private var lastFrameNs = 0L
    private var windowStartNs = 0L
    private var windowFrames = 0
    private var totalFrames = 0L
    private var runningNs = 0L
    private var minFps = Float.MAX_VALUE
    private var maxFps = 0f

    fun start() {
        timingReset = true
        running = true
    }

    fun stop() {
        running = false
    }

    fun resetStats() {
        statsReset = true
        timingReset = true
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.043f, 0.051f, 0.071f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_CULL_FACE)
        GLES20.glCullFace(GLES20.GL_BACK)
        cube = Cube()
        Matrix.setLookAtM(view, 0, 0f, 0f, 3.6f, 0f, 0f, 0f, 0f, 1f, 0f)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val ratio = width.toFloat() / height.toFloat()
        Matrix.perspectiveM(proj, 0, 45f, ratio, 0.1f, 20f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()

        if (statsReset) {
            statsReset = false
            totalFrames = 0
            windowFrames = 0
            runningNs = 0
            minFps = Float.MAX_VALUE
            maxFps = 0f
        }

        val isRunning = running
        if (isRunning) {
            if (timingReset) {
                timingReset = false
                lastFrameNs = now
                windowStartNs = now
                windowFrames = 0
            }
            val dtNs = now - lastFrameNs
            lastFrameNs = now
            runningNs += dtNs
            val dt = dtNs / 1_000_000_000f
            // Vitesse de rotation indépendante du FPS (degrés par seconde)
            angleX = (angleX + 45f * dt) % 360f
            angleY = (angleY + 70f * dt) % 360f
        }

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        Matrix.setIdentityM(model, 0)
        Matrix.rotateM(model, 0, angleX, 1f, 0f, 0f)
        Matrix.rotateM(model, 0, angleY, 0f, 1f, 0f)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        cube?.draw(mvp, model)

        if (isRunning) {
            totalFrames++
            windowFrames++
            val elapsed = now - windowStartNs
            if (elapsed >= 500_000_000L) {
                val fps = windowFrames * 1_000_000_000f / elapsed
                if (fps < minFps) minFps = fps
                if (fps > maxFps) maxFps = fps
                val avg = if (runningNs > 0) totalFrames * 1_000_000_000f / runningNs else 0f
                onStats(FpsStats(fps, totalFrames, avg, minFps, maxFps))
                windowFrames = 0
                windowStartNs = now
            }
        }
    }
}
